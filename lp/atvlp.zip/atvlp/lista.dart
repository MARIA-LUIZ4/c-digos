void main() {
  var lista = [0, 0, 0];
  lista[0] = 1;
  lista[1] = 2;
  lista[2] = 3;
  print(lista);
  print("Tamanho da lista é: ${lista.length}");
}
